package com.example.ca1sep

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.GridView
import android.widget.ProgressBar


class MainActivity : AppCompatActivity() {

    private lateinit var etTimeInSeconds: EditText
    private lateinit var btnStart: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var gridView: GridView
    private val holidays = arrayOf(
        "Holiday 1",
        "Holiday 2",
        "Holiday 3",
        "Holiday 4",
        "Holiday 5",
        "Holiday 6",
        "Holiday 7",
        "Holiday 8",
        "Holiday 9",


        )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etTimeInSeconds = findViewById(R.id.etTimeInSeconds)
        btnStart = findViewById(R.id.btnStart)
        progressBar = findViewById(R.id.progressBar)
        gridView = findViewById(R.id.gridView)

        btnStart.setOnClickListener {
            val timeInSeconds = etTimeInSeconds.text.toString().toIntOrNull()
            if (timeInSeconds != null) {
                startProgressBar(timeInSeconds)
            }
        }
    }

    private fun startProgressBar(timeInSeconds: Int) {
        progressBar.visibility = View.VISIBLE
        gridView.visibility = View.GONE

        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            progressBar.visibility = View.GONE
            gridView.visibility = View.VISIBLE

            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, holidays)
            gridView.adapter = adapter
        }, timeInSeconds * 1000L)
    }
}
